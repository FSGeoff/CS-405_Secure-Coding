#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>


/// <summary>
/// Encrypts or decrypts a source string using the provided key
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption / decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get lengths now instead of calling the function every time.
    // This would have most likely been inlined by the compiler, but design for performance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // Transform each character based on an XOR of the key modded constrained to key length using a mod
        output[i] = source[i] ^ key[i % key_length];
    }

    // Our output length must equal our source length
    assert(output.length() == source_length);

    // Return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline
    size_t pos = string_data.find('\n');

    // Did we find a newline?
    if (pos != std::string::npos)
    {
        // We did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& encrypted_data)
{
    std::ofstream file(filename);

    // Write student name to file
    file << student_name << std::endl;

    // Write encrypted data to file
    file << encrypted_data;
}

int main()
{
    // Define the source string and encryption key
    std::string source = "Hello, World!";
    std::string key = "myencryptionkey";

    // Encrypt the source string using XOR encryption
    std::string encrypted = encrypt_decrypt(source, key);
    std::cout << "Encrypted: " << encrypted << std::endl;

    // Decrypt the encrypted string using the same key
    std::string decrypted = encrypt_decrypt(encrypted, key);
    std::cout << "Decrypted: " << decrypted << std::endl;

    // Define the student name and filenames for encrypted and decrypted data
    std::string student_name = "John Doe";
    std::string encrypted_filename = "encrypted_data.txt";
    std::string decrypted_filename = "decrypted_data.txt";

    // Save the encrypted data to a file
    save_data_file(encrypted_filename, student_name, key, encrypted);

    // Save the decrypted data to a file
    save_data_file(decrypted_filename, student_name, key, decrypted);

    return 0;
}